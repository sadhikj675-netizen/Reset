90-Day Life Reset PWA

Files:
- index.html — app
- manifest.json — PWA manifest
- sw.js — offline service worker

How to use:
1. Put these files on an HTTPS website (or localhost).
2. Open index.html in Chrome.
3. Use Chrome's "Add to Home screen"/"Install app" option.
4. Your progress is stored in the browser's local storage.

The app includes 90 days, weekly navigation, seven daily habits, daily reflection, weekly review, overall completion percentage, and a streak counter.
